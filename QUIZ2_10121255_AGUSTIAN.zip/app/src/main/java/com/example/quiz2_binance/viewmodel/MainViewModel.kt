package com.example.quiz2_binance.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.quiz2_binance.model.TickerPrice
import com.example.quiz2_binance.api.RetrofitInstance
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel : ViewModel() {

    val price = MutableLiveData<TickerPrice>()

    fun getPrice(symbol: String) {
        RetrofitInstance.api.getPrice(symbol).enqueue(object : Callback<TickerPrice> {
            override fun onResponse(call: Call<TickerPrice>, response: Response<TickerPrice>) {
                if (response.isSuccessful) {
                    price.postValue(response.body())
                }
            }

            override fun onFailure(call: Call<TickerPrice>, t: Throwable) {
                // Handle error
            }
        })
    }
}