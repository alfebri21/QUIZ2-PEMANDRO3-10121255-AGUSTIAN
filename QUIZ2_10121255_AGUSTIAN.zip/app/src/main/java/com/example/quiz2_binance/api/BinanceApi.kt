package com.example.quiz2_binance.api

import com.example.quiz2_binance.model.TickerPrice
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface BinanceApi {
    @GET("/api/v3/ticker/price")
    fun getPrice(@Query("symbol") symbol: String): Call<TickerPrice>
}