package com.example.quiz2_binance

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.quiz2_binance.model.TickerPrice
import com.example.quiz2_binance.api.RetrofitInstance
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var etSymbol: EditText
    private lateinit var btnGetPrice: Button
    private lateinit var tvPrice: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etSymbol = findViewById(R.id.etSymbol)
        btnGetPrice = findViewById(R.id.btnGetPrice)
        tvPrice = findViewById(R.id.tvPrice)

        btnGetPrice.setOnClickListener {
            val symbol = etSymbol.text.toString().trim()
            if (symbol.isNotEmpty()) {
                getPrice(symbol)
            }
        }
    }

    private fun getPrice(symbol: String) {
        RetrofitInstance.api.getPrice(symbol).enqueue(object : Callback<TickerPrice> {
            override fun onResponse(call: Call<TickerPrice>, response: Response<TickerPrice>) {
                if (response.isSuccessful && response.body() != null) {
                    val tickerPrice = response.body()!!
                    tvPrice.text = "Price: ${tickerPrice.price}"
                } else {
                    Toast.makeText(this@MainActivity, "Failed to load price: ${response.message()}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<TickerPrice>, t: Throwable) {
                Toast.makeText(this@MainActivity, "API call failed: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
