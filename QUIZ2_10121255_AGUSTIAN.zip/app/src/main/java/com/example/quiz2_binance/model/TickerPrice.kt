package com.example.quiz2_binance.model

data class TickerPrice(
    val symbol: String,
    val price: String
)